<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="css/footer.css">
</head>

</html>