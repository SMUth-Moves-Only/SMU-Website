<?php
include "header.php";
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="stylesheet" href="css/group_data.css">
    <meta charset="utf-8">
    <title>groupdata</title>
  </head>

  <body>
    
    <div class="data">
      <label>Select Class:</label>
      <select name="SelectClass"></select>
   <br>
      <label>Select Group:</label>
      <select name="SelectGroup"></select>
   <br>
      <label>Select Date:</label>
      <input type="date" id="calendar" name="startdateselect">
      </form>
   <br>
      <button type="button" name="submit"> SUBMIT </button>
    </div>

  </body>
</html>
