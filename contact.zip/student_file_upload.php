<!DOCTYPE html>
<html>

<body>

    <form action="includes/professor_student_import.inc.php" method="post" enctype="multipart/form-data">
        Select image to upload:
        <input type="file" name="fileToUpload" id="fileToUpload">
        <input type="submit" value="Import Student" name="student-import">
    </form>

</body>

</html>