<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="css/footer.css">
</head>
<!--footer-->

<div style="background-color: black; color: white; font-size: 2vw; text-align: center; padding: 10px;">&copy; 2021 - Singapore Management University</div>


<!--
<div class="footer">
  <img src="img/blackbg.jpg" style="width:100%; height:20em">
  <div class="foottext">
      <h4>WHERE TO FIND US</h4>
        <p>Administration Building <br>Singapore Management University <br>81 Victoria Street <br>Singapore 188065</p>
      <br><br><br><br>
        <p>Terms of Use | Personal Data Protection Statement | Contact Data Protection Officer | Withdrawal of Consent | Website Feedback | Whistleblowing Form <br>© Copyright 2021 Singapore Management University. All Rights Reserved</p>
  </div>
  <div class="vtechbrand">
        <p>Made by SMUth Moves <br>from Virginia Tech</p>
  </div>
  <div class="contact">
        <h4>GET IN TOUCH</h4>
        <p>Email: enquiry@smu.edu.sg <br>Tel: +65 6828 0100 <br>Fax: +65 6828 0101</p>
  </div>
</div>-->
</html>
