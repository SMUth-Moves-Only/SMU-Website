<?php
include "header.php";
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">
  <title>peerevaluation</title>
</head>

<link rel="stylesheet" href="css/evaluationsuccess.css">

<body>
  <div class="checkmark">
    <img src="img/checkmark.svg" alt="check">
  </div>

  <h3>Thank you! <br> The group has been created <br> successfully.</h3>

  <h1>Student(s) have been assigned to the created group.</h1>

</body>

</html>
